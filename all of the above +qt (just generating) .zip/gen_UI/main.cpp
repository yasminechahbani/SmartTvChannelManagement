#include "statwindow.h"

#include "mainwindow.h"
#include <QMessageBox>
#include <QApplication>
#include <QLineEdit>
//#include <QFrame>
#include <QPushButton>
#include <QHoverEvent>
//#include <QVBoxLayout>
//added
//#include<QFile>
//#include<QDebug>
#include "connexion.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Connection c;
   /* QLineEdit lineEdit;
    lineEdit.show(); ikharjhellk outside mel mainwindow.cpp*/
/*    QFile styleFile("C:/Users/user/OneDrive/Documents/gen_UI/lineEdit.qss");
      styleFile.open(QFile::ReadOnly);
      QString styleSheet = QLatin1String(styleFile.readAll());
      a.setStyleSheet(styleSheet);*/

   bool test=c.createconnect();


   if (test)
   {w.show();
       QMessageBox::information(nullptr,QObject::tr("database is open"),
                             QObject::tr("connection successful.\n"
                                         "Clicl cancel to exit ."), QMessageBox::Cancel);
   }
   else
       QMessageBox::critical(nullptr,QObject::tr("database is not open"),
                             QObject::tr("connection failed.\n"
                                         "Clicl cancel to exit ."), QMessageBox::Cancel);
 //StatWindow statWindow;
 //QObject::connect(&w, &MainWindow::on_stats_button_clicked, &statWindow, &StatWindow::show);



return a.exec();


}
