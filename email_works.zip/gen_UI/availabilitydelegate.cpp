#include "availabilitydelegate.h"

AvailabilityDelegate::AvailabilityDelegate()
{

}
