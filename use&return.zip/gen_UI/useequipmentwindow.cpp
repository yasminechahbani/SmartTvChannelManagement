#include "useequipmentwindow.h"
#include "ui_useequipmentwindow.h"
#include "equipement.h"

useequipmentwindow::useequipmentwindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::useequipmentwindow)
{
    ui->setupUi(this);
}

useequipmentwindow::~useequipmentwindow()
{
    delete ui;
}

void useequipmentwindow::on_list_clicked()
{     ui->tableView->setModel(Equipmp.showEquipement());


}

///
///
///
///
///
///
///
///
///
/*void useequipmentwindow::sendWhatsAppMessage(const QString& recipient, const QString& message)
{
    QString accountSid = "AC09bc536f4fdf41cd9a4d1ac5ad9e36fe";
       QString authToken = "0d13b6af8a725faa1d4ec46b458f9347";
       QString fromNumber = "whatsapp:+14155238886";

       QNetworkAccessManager* manager = new QNetworkAccessManager(this);
       connect(manager, &QNetworkAccessManager::finished, this, &useequipmentwindow::onWhatsAppRequestFinished);

       QUrl url("https://api.twilio.com/2010-04-01/Accounts/" + accountSid + "/Messages.json");
       QNetworkRequest request(url);
       request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");

       QUrlQuery params;
       params.addQueryItem("To", "whatsapp:" + recipient);
       params.addQueryItem("From", fromNumber);
       params.addQueryItem("Body", message);
       QByteArray postData = params.toString(QUrl::FullyEncoded).toUtf8();

       QString auth = accountSid + ":" + authToken;
       QByteArray authData = auth.toUtf8().toBase64();
       request.setRawHeader("Authorization", "Basic " + authData);

       manager->post(request, postData);
}

void useequipmentwindow::onWhatsAppRequestFinished(QNetworkReply* reply)
{
    if (reply->error() == QNetworkReply::NoError) {
        QMessageBox::information(this, "WhatsApp Message Sent", "The WhatsApp message has been sent successfully.");
    } else {
        QMessageBox::critical(this, "Error", "Failed to send WhatsApp message: " + reply->errorString());
    }
    reply->deleteLater();
}
*/
/////////////////////////////////////////////////
    void useequipmentwindow::on_tableView_activated(const QModelIndex &index)
    {
        QString equipmentID = ui->tableView->model()->data(index.sibling(index.row(), 0)).toString();

           // Retrieve the availability of the equipment from the table view
           QString availability = ui->tableView->model()->data(index.sibling(index.row(), 3)).toString();

           // Check if the equipment is available
           if (availability == "AVAILABLE") {
               // Ask for confirmation using QMessageBox
               QMessageBox::StandardButton reply;
               reply = QMessageBox::question(this, "Confirmation", "Do you want to use this equipment?", QMessageBox::Yes | QMessageBox::No);

               // Check user's response
               if (reply == QMessageBox::Yes) {
                   // Update the availability in the database
                   QSqlQuery query;
                   query.prepare("UPDATE EQUIPEMENT SET EQUIPEMENT_AVAILABILITY = :availability WHERE EQUIPEMENT_ID = :id");
                   query.bindValue(":availability", "IN USE");
                   query.bindValue(":id", equipmentID);

                   if (query.exec()) {
                       // Send WhatsApp message
                      // sendWhatsAppMessage("RECIPIENT_PHONE_NUMBER", "Your equipment with ID " + equipmentID + " is now in use.");
                       ui->tableView->model()->setData(index.sibling(index.row(), 3), "IN USE");

                                     // Refresh the table view by reloading the data from the database
                                     QSqlQueryModel* model = Equipmp.showEquipement();
                                     ui->tableView->setModel(model);

                                     // Notify the user about the equipment being used
                                     QMessageBox::information(this, "Success", "Equipment used successfully.");

                   } else {
                       QMessageBox::warning(this, "Error", "Failed to update equipment availability in the database.");
                   }
               }
           } else {
               // Notify the user that the equipment is not available for use
               QMessageBox::warning(this, "Warning", "This equipment is not available for use.");
           }
    }



